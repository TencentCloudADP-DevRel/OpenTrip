/* @ds-bundle: {"format":3,"namespace":"CossUIDesignSystem_2babcc","components":[{"name":"Alert","sourcePath":"components/core/Alert.jsx"},{"name":"AlertTitle","sourcePath":"components/core/Alert.jsx"},{"name":"AlertDescription","sourcePath":"components/core/Alert.jsx"},{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"CardTitle","sourcePath":"components/core/Card.jsx"},{"name":"CardDescription","sourcePath":"components/core/Card.jsx"},{"name":"CardContent","sourcePath":"components/core/Card.jsx"},{"name":"CardFooter","sourcePath":"components/core/Card.jsx"},{"name":"Checkbox","sourcePath":"components/core/Checkbox.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"Tabs","sourcePath":"components/core/Tabs.jsx"}],"sourceHashes":{"components/core/Alert.jsx":"b14054574703","components/core/Avatar.jsx":"808dba8b9ed9","components/core/Badge.jsx":"18bceb84e0e4","components/core/Button.jsx":"cb0e3d0d3655","components/core/Card.jsx":"e3e9725527e9","components/core/Checkbox.jsx":"49487e9383dc","components/core/Input.jsx":"2ad69e75550f","components/core/Switch.jsx":"5e9a4047a465","components/core/Tabs.jsx":"cb75b6aaf90b","ui_kits/scheduling/App.jsx":"23e45c7c7180","ui_kits/scheduling/BookingForm.jsx":"eaef1894d7dd","ui_kits/scheduling/Confirmation.jsx":"1fff80503856","ui_kits/scheduling/EventTypeList.jsx":"b531f06a2324","ui_kits/scheduling/Scheduler.jsx":"134750a0ed6a","ui_kits/scheduling/icons.jsx":"6e1d9b9df094"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CossUIDesignSystem_2babcc = window.CossUIDesignSystem_2babcc || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-alert{
  position:relative; display:grid; grid-template-columns:1fr; gap:.125rem .5rem;
  width:100%; padding:.75rem .875rem; border-radius:var(--radius-xl);
  border:1px solid var(--border); background:transparent;
  color:var(--card-foreground); font-size:var(--text-base);
}
.coss-alert:has(.coss-alert-icon){ grid-template-columns:1rem 1fr; }
.coss-alert-icon{ width:1rem; height:1rem; margin-top:.05rem; color:var(--muted-foreground); }
.coss-alert-icon svg{ width:100%; height:100%; }
.coss-alert-title{ font-weight:var(--weight-medium); text-wrap:balance; }
.coss-alert-desc{ color:var(--muted-foreground); line-height:var(--leading-snug); text-wrap:pretty; }
.coss-alert .coss-alert-title, .coss-alert .coss-alert-desc{ grid-column:1; }
.coss-alert:has(.coss-alert-icon) .coss-alert-title, .coss-alert:has(.coss-alert-icon) .coss-alert-desc{ grid-column:2; }

.coss-alert[data-variant="info"]{ border-color:color-mix(in srgb,var(--info) 32%,transparent); background:color-mix(in srgb,var(--info) 5%,transparent); }
.coss-alert[data-variant="info"] .coss-alert-icon{ color:var(--info); }
.coss-alert[data-variant="success"]{ border-color:color-mix(in srgb,var(--success) 32%,transparent); background:color-mix(in srgb,var(--success) 5%,transparent); }
.coss-alert[data-variant="success"] .coss-alert-icon{ color:var(--success); }
.coss-alert[data-variant="warning"]{ border-color:color-mix(in srgb,var(--warning) 36%,transparent); background:color-mix(in srgb,var(--warning) 6%,transparent); }
.coss-alert[data-variant="warning"] .coss-alert-icon{ color:var(--warning); }
.coss-alert[data-variant="error"]{ border-color:color-mix(in srgb,var(--destructive) 32%,transparent); background:color-mix(in srgb,var(--destructive) 5%,transparent); }
.coss-alert[data-variant="error"] .coss-alert-icon{ color:var(--destructive); }
`;
function Alert({
  variant = "default",
  icon,
  className,
  children,
  ...props
}) {
  useStyles("alert", CSS);
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "alert",
    "data-variant": variant,
    "data-slot": "alert",
    className: cx("coss-alert", className)
  }, props), icon ? /*#__PURE__*/React.createElement("span", {
    className: "coss-alert-icon"
  }, icon) : null, children);
}
function AlertTitle({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "alert-title",
    className: cx("coss-alert-title", className)
  }, props));
}
function AlertDescription({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "alert-description",
    className: cx("coss-alert-desc", className)
  }, props));
}
Object.assign(__ds_scope, { Alert, AlertTitle, AlertDescription });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Alert.jsx", error: String((e && e.message) || e) }); }

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-avatar{
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  width:2.25rem; height:2.25rem; flex-shrink:0; overflow:hidden;
  border-radius:var(--radius-full); background:var(--secondary); color:var(--ink-600);
  font-family:var(--font-sans); font-weight:var(--weight-medium); font-size:var(--text-sm);
  user-select:none; box-shadow: inset 0 0 0 1px var(--border);
}
.coss-avatar[data-size="sm"]{ width:1.75rem; height:1.75rem; font-size:var(--text-xs); }
.coss-avatar[data-size="lg"]{ width:2.75rem; height:2.75rem; font-size:var(--text-md); }
.coss-avatar[data-size="xl"]{ width:3.5rem; height:3.5rem; font-size:var(--text-lg); }
.coss-avatar img{ width:100%; height:100%; object-fit:cover; }
`;
function Avatar({
  src,
  alt = "",
  fallback,
  size = "default",
  className,
  ...props
}) {
  useStyles("avatar", CSS);
  const [errored, setErrored] = React.useState(false);
  const showImg = src && !errored;
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-slot": "avatar",
    "data-size": size,
    className: cx("coss-avatar", className)
  }, props), showImg ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: alt,
    onError: () => setErrored(true)
  }) : /*#__PURE__*/React.createElement("span", {
    "data-slot": "avatar-fallback"
  }, fallback));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-badge{
  --h:1.375rem; --fs:var(--text-xs);
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  gap:.25rem; white-space:nowrap; flex-shrink:0;
  height:var(--h); min-width:var(--h); padding-inline:.375rem;
  border-radius:var(--radius-sm); border:1px solid transparent;
  font-family:var(--font-sans); font-size:var(--fs); font-weight:var(--weight-medium); line-height:1;
}
.coss-badge svg{ width:.85em; height:.85em; opacity:.85; }
.coss-badge[data-size="sm"]{ --h:1.25rem; --fs:.625rem; border-radius:var(--radius-xs); }
.coss-badge[data-size="lg"]{ --h:1.625rem; --fs:var(--text-sm); padding-inline:.5rem; }

.coss-badge[data-variant="default"]{ background:var(--primary); color:var(--primary-foreground); }
.coss-badge[data-variant="brand"]{ background:var(--brand); color:var(--brand-foreground); }
.coss-badge[data-variant="secondary"]{ background:var(--secondary); color:var(--secondary-foreground); }
.coss-badge[data-variant="outline"]{ background:var(--background); color:var(--foreground); border-color:var(--input); }
.coss-badge[data-variant="info"]{ background:color-mix(in srgb,var(--info) 10%,transparent); color:var(--info-foreground); }
.coss-badge[data-variant="success"]{ background:color-mix(in srgb,var(--success) 12%,transparent); color:var(--success-foreground); }
.coss-badge[data-variant="warning"]{ background:color-mix(in srgb,var(--warning) 16%,transparent); color:var(--warning-foreground); }
.coss-badge[data-variant="error"]{ background:color-mix(in srgb,var(--destructive) 10%,transparent); color:var(--destructive-foreground); }
`;
function Badge({
  variant = "default",
  size = "default",
  className,
  children,
  ...props
}) {
  useStyles("badge", CSS);
  return /*#__PURE__*/React.createElement("span", _extends({
    "data-variant": variant,
    "data-size": size,
    "data-slot": "badge",
    className: cx("coss-badge", className)
  }, props), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-btn{
  --h: 2.25rem; --px: 0.6875rem; --fs: var(--text-base); --r: var(--radius-lg);
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  gap:.5rem; white-space:nowrap; flex-shrink:0; cursor:pointer; user-select:none;
  height:var(--h); padding-inline:var(--px); border-radius:var(--r);
  font-family:var(--font-sans); font-size:var(--fs); font-weight:var(--weight-medium);
  line-height:1; border:1px solid transparent; outline:none;
  transition: background-color .15s ease, box-shadow .15s ease, opacity .15s ease, border-color .15s ease, scale .12s var(--ease-out);
}
.coss-btn:disabled{ pointer-events:none; opacity:.64; }
.coss-btn:not([data-static="true"]):not([data-variant="link"]):active:not(:disabled){ scale: var(--press-scale); }
.coss-btn:focus-visible{ box-shadow:0 0 0 var(--ring-offset) var(--background), 0 0 0 calc(var(--ring-offset) + 2px) var(--ring); }
.coss-btn svg{ width:1.05em; height:1.05em; margin-inline:-.125rem; opacity:.8; flex-shrink:0; pointer-events:none; }

/* sizes */
.coss-btn[data-size="sm"]{ --h:2rem; --px:.5625rem; --fs:var(--text-sm); gap:.375rem; }
.coss-btn[data-size="xs"]{ --h:1.75rem; --px:.4375rem; --fs:var(--text-xs); --r:var(--radius-md); gap:.25rem; }
.coss-btn[data-size="lg"]{ --h:2.5rem; --px:.8125rem; }
.coss-btn[data-size="xl"]{ --h:2.75rem; --px:.9375rem; --fs:var(--text-md); }
.coss-btn[data-size="icon"]{ width:var(--h); padding:0; }
.coss-btn[data-size="icon-sm"]{ --h:2rem; width:var(--h); padding:0; }
.coss-btn[data-size="icon-lg"]{ --h:2.5rem; width:var(--h); padding:0; }

/* variant: default (navy ink) */
.coss-btn[data-variant="default"]{
  background:var(--primary); color:var(--primary-foreground); border-color:var(--primary);
  box-shadow: var(--highlight-top), var(--shadow-xs);
}
.coss-btn[data-variant="default"]:hover{ background:color-mix(in srgb, var(--primary) 90%, var(--background)); }
.coss-btn[data-variant="default"]:active{ box-shadow:var(--highlight-inset); }

/* variant: brand (cornflower) */
.coss-btn[data-variant="brand"]{
  background:var(--brand); color:var(--brand-foreground); border-color:var(--brand);
  box-shadow: var(--highlight-top), var(--shadow-xs);
}
.coss-btn[data-variant="brand"]:hover{ background:var(--corn-600); }
.coss-btn[data-variant="brand"]:active{ box-shadow:var(--highlight-inset); }

/* variant: secondary */
.coss-btn[data-variant="secondary"]{ background:var(--secondary); color:var(--secondary-foreground); }
.coss-btn[data-variant="secondary"]:hover{ background:color-mix(in srgb, var(--ink-900) 8%, transparent); }

/* variant: outline */
.coss-btn[data-variant="outline"]{
  background:var(--popover); color:var(--foreground); border-color:var(--input);
  box-shadow: var(--highlight-inset), var(--shadow-xs);
}
.coss-btn[data-variant="outline"]:hover{ background:color-mix(in srgb, var(--accent) 55%, transparent); }

/* variant: ghost */
.coss-btn[data-variant="ghost"]{ background:transparent; color:var(--foreground); }
.coss-btn[data-variant="ghost"]:hover{ background:var(--accent); }

/* variant: link */
.coss-btn[data-variant="link"]{ background:transparent; color:var(--brand); padding-inline:0; height:auto; border-color:transparent; }
.coss-btn[data-variant="link"]:hover{ text-decoration:underline; text-underline-offset:4px; }

/* variant: destructive */
.coss-btn[data-variant="destructive"]{
  background:var(--destructive); color:#fff; border-color:var(--destructive);
  box-shadow: var(--highlight-top), var(--shadow-xs);
}
.coss-btn[data-variant="destructive"]:hover{ background:color-mix(in srgb, var(--destructive) 90%, var(--background)); }
`;
function Button({
  variant = "default",
  size = "default",
  className,
  type = "button",
  static: isStatic = false,
  children,
  ...props
}) {
  useStyles("button", CSS);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    "data-variant": variant,
    "data-size": size,
    "data-static": isStatic || undefined,
    "data-slot": "button",
    className: cx("coss-btn", className)
  }, props), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-card{
  position:relative; display:flex; flex-direction:column;
  border-radius:var(--radius-2xl); border:1px solid var(--border);
  background:var(--card); color:var(--card-foreground);
  box-shadow: var(--highlight-inset), var(--shadow-sm);
}
.coss-card-header{ display:flex; flex-direction:column; gap:.375rem; padding:1.5rem 1.5rem 0; }
.coss-card-title{ font-family:var(--font-heading); font-weight:var(--weight-semibold); font-size:var(--text-lg); line-height:1.2; letter-spacing:var(--tracking-snug); text-wrap:balance; }
.coss-card-desc{ color:var(--muted-foreground); font-size:var(--text-base); line-height:var(--leading-normal); text-wrap:pretty; }
.coss-card-content{ padding:1.25rem 1.5rem; flex:1; }
.coss-card-footer{ display:flex; align-items:center; gap:.5rem; padding:0 1.5rem 1.5rem; }
`;
function Card({
  className,
  children,
  ...props
}) {
  useStyles("card", CSS);
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card",
    className: cx("coss-card", className)
  }, props), children);
}
function CardHeader({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-header",
    className: cx("coss-card-header", className)
  }, props));
}
function CardTitle({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-title",
    className: cx("coss-card-title", className)
  }, props));
}
function CardDescription({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-description",
    className: cx("coss-card-desc", className)
  }, props));
}
function CardContent({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-content",
    className: cx("coss-card-content", className)
  }, props));
}
function CardFooter({
  className,
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    "data-slot": "card-footer",
    className: cx("coss-card-footer", className)
  }, props));
}
Object.assign(__ds_scope, { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-checkbox{
  position:relative; display:inline-flex; align-items:center; justify-content:center;
  width:1.125rem; height:1.125rem; flex-shrink:0; cursor:pointer;
  border-radius:var(--radius-xs); border:1px solid var(--input); background:var(--background);
  box-shadow: var(--highlight-inset); transition: background-color .12s ease, border-color .12s ease, box-shadow .15s ease, scale .1s var(--ease-out);
}
/* Extend the hit area to 40×40 (the box is only 18px). If two checkboxes sit
   closer than 40px, shrink this so their hit areas never overlap. */
.coss-checkbox::after{ content:""; position:absolute; top:50%; left:50%; transform:translate(-50%,-50%); width:40px; height:40px; }
.coss-checkbox:active:not([data-disabled="true"]){ scale: var(--press-scale); }
.coss-checkbox:focus-visible{ outline:none; box-shadow:0 0 0 var(--ring-offset) var(--background), 0 0 0 calc(var(--ring-offset)+2px) var(--ring); }
.coss-checkbox[data-checked="true"]{ background:var(--primary); border-color:var(--primary); }
.coss-checkbox[data-disabled="true"]{ opacity:.64; cursor:not-allowed; }
.coss-checkbox svg{ width:.75rem; height:.75rem; color:var(--primary-foreground); stroke-width:3; opacity:0; transition:opacity .1s ease; }
.coss-checkbox[data-checked="true"] svg{ opacity:1; }
`;
function Checkbox({
  checked,
  defaultChecked,
  onCheckedChange,
  disabled,
  className,
  ...props
}) {
  useStyles("checkbox", CSS);
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(Boolean(defaultChecked));
  const value = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(v => !v);
    onCheckedChange && onCheckedChange(!value);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "checkbox",
    "aria-checked": value,
    "data-checked": value,
    "data-disabled": disabled || undefined,
    "data-slot": "checkbox",
    disabled: disabled,
    onClick: toggle,
    className: cx("coss-checkbox", className)
  }, props), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M5.252 12.7 10.2 18.63 18.748 5.37"
  })));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-input-wrap{
  position:relative; display:inline-flex; width:100%;
  border-radius:var(--radius-lg); border:1px solid var(--input);
  background:var(--background); color:var(--foreground);
  box-shadow: var(--highlight-inset), var(--shadow-xs);
  transition: box-shadow .15s ease, border-color .15s ease;
}
.coss-input-wrap:focus-within{ border-color:var(--ring); box-shadow:0 0 0 var(--ring-width) color-mix(in srgb,var(--ring) 24%,transparent); }
.coss-input-wrap[data-invalid="true"]{ border-color:color-mix(in srgb,var(--destructive) 60%,transparent); }
.coss-input-wrap[data-invalid="true"]:focus-within{ box-shadow:0 0 0 var(--ring-width) color-mix(in srgb,var(--destructive) 20%,transparent); }
.coss-input{
  height:2.125rem; width:100%; min-width:0; border:0; outline:none; background:transparent;
  padding-inline:.6875rem; font-family:var(--font-sans); font-size:var(--text-base); color:inherit;
}
.coss-input::placeholder{ color:color-mix(in srgb,var(--muted-foreground) 72%,transparent); }
.coss-input-wrap[data-size="sm"] .coss-input{ height:1.875rem; padding-inline:.5625rem; font-size:var(--text-sm); }
.coss-input-wrap[data-size="lg"] .coss-input{ height:2.375rem; }
.coss-input-wrap:has(:disabled){ opacity:.64; }
`;
function Input({
  size = "default",
  invalid = false,
  className,
  style,
  ...props
}) {
  useStyles("input", CSS);
  return /*#__PURE__*/React.createElement("span", {
    className: cx("coss-input-wrap", className),
    "data-size": size,
    "data-invalid": invalid,
    "data-slot": "input-control",
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    className: "coss-input",
    "data-slot": "input",
    "aria-invalid": invalid || undefined
  }, props)));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-switch{
  --thumb:1.25rem;
  position:relative; display:inline-flex; align-items:center; flex-shrink:0; cursor:pointer;
  height:calc(var(--thumb) + 2px); width:calc(var(--thumb)*2 - 2px); padding:1px;
  border-radius:var(--radius-full); border:0; background:var(--input);
  transition: background-color .2s ease, box-shadow .15s ease;
}
.coss-switch:focus-visible{ outline:none; box-shadow:0 0 0 var(--ring-offset) var(--background), 0 0 0 calc(var(--ring-offset)+2px) var(--ring); }
.coss-switch[data-checked="true"]{ background:var(--primary); }
.coss-switch[data-disabled="true"]{ opacity:.64; cursor:not-allowed; }
.coss-switch-thumb{
  display:block; aspect-ratio:1; height:100%; border-radius:var(--radius-full);
  background:var(--background); box-shadow:var(--shadow-sm);
  transition: transform .16s var(--ease-out); will-change: transform;
}
.coss-switch[data-checked="true"] .coss-switch-thumb{ transform:translateX(calc(var(--thumb) - 4px)); }
`;
function Switch({
  checked,
  defaultChecked,
  onCheckedChange,
  disabled,
  className,
  ...props
}) {
  useStyles("switch", CSS);
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(Boolean(defaultChecked));
  const value = isControlled ? checked : internal;
  const toggle = () => {
    if (disabled) return;
    if (!isControlled) setInternal(v => !v);
    onCheckedChange && onCheckedChange(!value);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": value,
    "data-checked": value,
    "data-disabled": disabled || undefined,
    "data-slot": "switch",
    disabled: disabled,
    onClick: toggle,
    className: cx("coss-switch", className)
  }, props), /*#__PURE__*/React.createElement("span", {
    className: "coss-switch-thumb",
    "data-slot": "switch-thumb"
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/core/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const _injected = new Set();
function useStyles(id, css) {
  if (typeof document === "undefined" || _injected.has(id)) return;
  _injected.add(id);
  const el = document.createElement("style");
  el.setAttribute("data-coss", id);
  el.textContent = css;
  document.head.appendChild(el);
}
function cx() {
  return Array.prototype.slice.call(arguments).filter(Boolean).join(" ");
}
const CSS = `
.coss-tabs-list{
  display:inline-flex; align-items:center; gap:.125rem; padding:.25rem;
  border-radius:var(--radius-lg); background:var(--secondary);
}
.coss-tab{
  position:relative; display:inline-flex; align-items:center; justify-content:center; gap:.375rem;
  height:1.875rem; padding-inline:.75rem; border:0; cursor:pointer; background:transparent;
  border-radius:var(--radius-md); font-family:var(--font-sans); font-size:var(--text-sm);
  font-weight:var(--weight-medium); color:var(--muted-foreground);
  transition: color .12s ease, background-color .12s ease, box-shadow .12s ease;
}
.coss-tab:hover{ color:var(--foreground); }
.coss-tab:focus-visible{ outline:none; box-shadow:0 0 0 2px var(--ring); }
.coss-tab[data-active="true"]{ color:var(--foreground); background:var(--card); box-shadow:var(--shadow-xs); }
`;
function Tabs({
  tabs = [],
  value,
  defaultValue,
  onValueChange,
  className,
  ...props
}) {
  useStyles("tabs", CSS);
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue ?? (tabs[0] && tabs[0].value));
  const active = isControlled ? value : internal;
  const select = v => {
    if (!isControlled) setInternal(v);
    onValueChange && onValueChange(v);
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    role: "tablist",
    "data-slot": "tabs",
    className: cx("coss-tabs-list", className)
  }, props), tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.value,
    type: "button",
    role: "tab",
    "aria-selected": active === t.value,
    "data-active": active === t.value,
    className: "coss-tab",
    onClick: () => select(t.value)
  }, t.icon, t.label)));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/App.jsx
try { (() => {
function BookingSummary({
  event,
  pick
}) {
  const {
    Avatar,
    Badge
  } = window.CossUIDesignSystem_2babcc;
  const I = Icons[event.icon];
  const line = (icon, text) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 9,
      color: "var(--muted-foreground)",
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex"
    }
  }, icon), " ", text);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    fallback: "LY",
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--muted-foreground)"
    }
  }, "Lynn")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-heading)",
      fontWeight: 600,
      fontSize: 19,
      letterSpacing: "-0.01em",
      lineHeight: 1.2
    }
  }, event.title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, line(/*#__PURE__*/React.createElement(Icons.clock, {
    size: 15
  }), `${event.dur} minutes`), line(/*#__PURE__*/React.createElement(I, {
    size: 15
  }), event.type), line(/*#__PURE__*/React.createElement(Icons.globe, {
    size: 15
  }), "Asia/Shanghai (UTC+8)"), pick && line(/*#__PURE__*/React.createElement(Icons.calendar, {
    size: 15
  }), `Wed, Jun 24 · ${pick.slot}`)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--muted-foreground)",
      fontSize: 13,
      lineHeight: 1.55,
      margin: 0
    }
  }, event.desc));
}
function App() {
  const [step, setStep] = React.useState("event"); // event | slots | form | done
  const [event, setEvent] = React.useState(null);
  const [pick, setPick] = React.useState(null);
  const [attendee, setAttendee] = React.useState(null);
  const reset = () => {
    setStep("event");
    setEvent(null);
    setPick(null);
    setAttendee(null);
  };

  // Robust entrance: items rest VISIBLE; the keyframe fades them in only if it
  // actually runs. Some engines report animations as "running" but never advance
  // the timeline (currentTime frozen at 0), which would trap content at the
  // hidden keyframe. After a beat, cancel any animation that hasn't progressed
  // so content reverts to its visible base state.
  React.useEffect(() => {
    const root = document.querySelector(".stage");
    if (!root) return;
    const id = setTimeout(() => {
      root.querySelectorAll(".main-pad > *, .confirm > *").forEach(el => {
        el.getAnimations && el.getAnimations().forEach(a => {
          if ((a.currentTime || 0) < 1) a.cancel();
        });
      });
    }, 200);
    return () => clearTimeout(id);
  }, [step]);
  return /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("header", {
    className: "topbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "brand"
  }, /*#__PURE__*/React.createElement("span", {
    className: "brand-mark"
  }, "c"), /*#__PURE__*/React.createElement("span", {
    className: "brand-name"
  }, "coss", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted-foreground)"
    }
  }, "/ui"))), /*#__PURE__*/React.createElement("div", {
    className: "brand-tag"
  }, "Scheduling")), /*#__PURE__*/React.createElement("main", {
    className: "stage"
  }, step === "done" ? /*#__PURE__*/React.createElement("div", {
    className: "bcard bcard-single",
    "data-screen-label": "Confirmed"
  }, /*#__PURE__*/React.createElement(Confirmation, {
    event: event,
    pick: pick,
    attendee: attendee,
    onReset: reset
  })) : /*#__PURE__*/React.createElement("div", {
    className: "bcard",
    "data-screen-label": step === "event" ? "Event list" : step === "slots" ? "Scheduler" : "Details"
  }, /*#__PURE__*/React.createElement("aside", {
    className: "bcard-side"
  }, step === "event" ? /*#__PURE__*/React.createElement(HostProfile, null) : /*#__PURE__*/React.createElement(BookingSummary, {
    event: event,
    pick: pick
  })), /*#__PURE__*/React.createElement("section", {
    className: "bcard-main"
  }, step === "event" && /*#__PURE__*/React.createElement("div", {
    className: "main-pad"
  }, /*#__PURE__*/React.createElement("div", {
    className: "main-title"
  }, "Book a meeting"), /*#__PURE__*/React.createElement("div", {
    className: "main-sub"
  }, "Choose what you'd like to talk about."), /*#__PURE__*/React.createElement(EventTypeList, {
    onPick: e => {
      setEvent(e);
      setStep("slots");
    }
  })), step === "slots" && /*#__PURE__*/React.createElement(Scheduler, {
    event: event,
    onBack: reset,
    onConfirm: p => {
      setPick(p);
      setStep("form");
    }
  }), step === "form" && /*#__PURE__*/React.createElement("div", {
    className: "main-pad"
  }, /*#__PURE__*/React.createElement("div", {
    className: "main-title"
  }, "Enter your details"), /*#__PURE__*/React.createElement("div", {
    className: "main-sub"
  }, "Wed, Jun 24 \xB7 ", pick.slot, " \xB7 ", event.dur, " min"), /*#__PURE__*/React.createElement(BookingForm, {
    event: event,
    pick: pick,
    onBack: () => setStep("slots"),
    onSubmit: a => {
      setAttendee(a);
      setStep("done");
    }
  }))))));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/BookingForm.jsx
try { (() => {
// Attendee details form.
function BookingForm({
  event,
  pick,
  onSubmit,
  onBack
}) {
  const {
    Input,
    Checkbox,
    Button
  } = window.CossUIDesignSystem_2babcc;
  const [name, setName] = React.useState("");
  const [email, setEmail] = React.useState("");
  const [notes, setNotes] = React.useState("");
  const valid = name.trim() && /.+@.+\..+/.test(email);
  const Field = ({
    label,
    children,
    hint
  }) => /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontWeight: 500
    }
  }, label), children, hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11.5,
      color: "var(--muted-foreground)"
    }
  }, hint));
  return /*#__PURE__*/React.createElement("div", {
    className: "form"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(Field, {
    label: "Your name"
  }, /*#__PURE__*/React.createElement(Input, {
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "Jane Cooper"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "Email"
  }, /*#__PURE__*/React.createElement(Input, {
    type: "email",
    value: email,
    onChange: e => setEmail(e.target.value),
    placeholder: "jane@company.com"
  })), /*#__PURE__*/React.createElement(Field, {
    label: "What's it about?",
    hint: "Optional \u2014 share an agenda or links."
  }, /*#__PURE__*/React.createElement("textarea", {
    className: "ta",
    rows: 3,
    value: notes,
    onChange: e => setNotes(e.target.value),
    placeholder: "A few notes for Lynn\u2026"
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true
  }), " Email me a calendar invite")), /*#__PURE__*/React.createElement("div", {
    className: "sched-foot"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onBack
  }, /*#__PURE__*/React.createElement(Icons.arrowL, {
    size: 16
  }), " Back"), /*#__PURE__*/React.createElement(Button, {
    variant: "brand",
    disabled: !valid,
    onClick: () => onSubmit({
      name,
      email
    })
  }, "Confirm booking")));
}
Object.assign(window, {
  BookingForm
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/BookingForm.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/Confirmation.jsx
try { (() => {
// Confirmation screen.
function Confirmation({
  event,
  pick,
  attendee,
  onReset
}) {
  const {
    Button,
    Alert,
    AlertTitle,
    AlertDescription
  } = window.CossUIDesignSystem_2babcc;
  const I = Icons[event.icon];
  const row = (icon, text) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      color: "var(--foreground)",
      fontSize: 13.5
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--ink-500)",
      display: "inline-flex"
    }
  }, icon), " ", text);
  return /*#__PURE__*/React.createElement("div", {
    className: "confirm"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      textAlign: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--success)"
    }
  }, /*#__PURE__*/React.createElement(Icons.checkCircle, {
    size: 44,
    sw: 1.6
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-heading)",
      fontWeight: 600,
      fontSize: 20,
      letterSpacing: "-0.01em"
    }
  }, "You're booked"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--muted-foreground)",
      fontSize: 13.5,
      marginTop: 3
    }
  }, "A calendar invite is on its way to ", attendee.email, "."))), /*#__PURE__*/React.createElement("div", {
    className: "confirm-card"
  }, row(/*#__PURE__*/React.createElement(Icons.calendar, {
    size: 16
  }), "Wednesday, June 24, 2026"), row(/*#__PURE__*/React.createElement(Icons.clock, {
    size: 16
  }), `${pick.slot} – ${event.dur} min · UTC+8`), row(/*#__PURE__*/React.createElement(I, {
    size: 16
  }), event.type), row(/*#__PURE__*/React.createElement(Icons.user, {
    size: 16
  }), `Lynn & ${attendee.name}`)), /*#__PURE__*/React.createElement(Alert, {
    variant: "info",
    icon: /*#__PURE__*/React.createElement(Icons.video, {
      size: 16
    })
  }, /*#__PURE__*/React.createElement(AlertTitle, null, "Cal Video link"), /*#__PURE__*/React.createElement(AlertDescription, null, "Join from the calendar invite \u2014 no install needed.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "center",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    onClick: onReset
  }, "Book another time")));
}
Object.assign(window, {
  Confirmation
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/Confirmation.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/EventTypeList.jsx
try { (() => {
// Host profile + event list — the public booking landing.
const EVENTS = [{
  id: "intro",
  title: "Intro call",
  dur: 15,
  type: "Phone",
  icon: "phone",
  desc: "A quick hello to see if we're a fit."
}, {
  id: "walkthrough",
  title: "Product walkthrough",
  dur: 30,
  type: "Cal Video",
  icon: "video",
  desc: "A guided tour of the scheduling flow, end to end."
}, {
  id: "deep",
  title: "Design review",
  dur: 60,
  type: "Cal Video",
  icon: "video",
  desc: "Bring your work — we'll go deep on the details."
}];
function HostProfile({
  compact
}) {
  const {
    Avatar
  } = window.CossUIDesignSystem_2babcc;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: compact ? 10 : 14,
      alignItems: compact ? "flex-start" : "center",
      textAlign: compact ? "left" : "center"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    fallback: "LY",
    size: compact ? "lg" : "xl"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-heading)",
      fontWeight: 600,
      fontSize: compact ? 16 : 20,
      letterSpacing: "-0.01em"
    }
  }, "Lynn"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--muted-foreground)",
      fontSize: 13,
      marginTop: 2
    }
  }, "coss.com/ui \xB7 Design")), !compact && /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--muted-foreground)",
      fontSize: 13.5,
      lineHeight: 1.55,
      margin: 0,
      maxWidth: 240
    }
  }, "Pick a time below \u2014 calendar invite and meeting link sent automatically."));
}
function EventTypeList({
  onPick
}) {
  const {
    Badge
  } = window.CossUIDesignSystem_2babcc;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, EVENTS.map(e => {
    const I = Icons[e.icon];
    return /*#__PURE__*/React.createElement("button", {
      key: e.id,
      className: "evt",
      onClick: () => onPick(e)
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 15
      }
    }, e.title), /*#__PURE__*/React.createElement(Badge, {
      variant: "secondary"
    }, /*#__PURE__*/React.createElement(Icons.clock, {
      size: 12
    }), " ", e.dur, "m")), /*#__PURE__*/React.createElement("div", {
      style: {
        color: "var(--muted-foreground)",
        fontSize: 13,
        lineHeight: 1.5
      }
    }, e.desc), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        color: "var(--ink-500)",
        fontSize: 12.5,
        marginTop: 2
      }
    }, /*#__PURE__*/React.createElement(I, {
      size: 14
    }), " ", e.type));
  }));
}
Object.assign(window, {
  EventTypeList,
  HostProfile,
  EVENTS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/EventTypeList.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/Scheduler.jsx
try { (() => {
// Date + time picker. Month grid (June 2026) with available days, then slots.
function Scheduler({
  event,
  onConfirm,
  onBack
}) {
  const {
    Tabs,
    Button
  } = window.CossUIDesignSystem_2babcc;
  const [selected, setSelected] = React.useState(24); // Jun 24
  const [slot, setSlot] = React.useState(null);
  const [fmt, setFmt] = React.useState("12h");

  // June 2026: starts on Monday. We render Mon-first weeks.
  const daysInMonth = 30;
  const firstWeekday = 0; // Monday=0 offset (Jun 1 2026 is a Monday)
  const today = 18;
  const cells = [];
  for (let i = 0; i < firstWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) cells.push(d);
  const isAvailable = d => d && d >= today && ![20, 21, 27, 28].includes(d); // weekends off
  const slots12 = ["9:00 am", "9:30 am", "10:00 am", "11:00 am", "1:00 pm", "1:30 pm", "2:00 pm", "3:30 pm"];
  const slots24 = ["09:00", "09:30", "10:00", "11:00", "13:00", "13:30", "14:00", "15:30"];
  const slots = fmt === "12h" ? slots12 : slots24;
  return /*#__PURE__*/React.createElement("div", {
    className: "sched"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sched-cal"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cal-head"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14
    }
  }, "June 2026"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "icon-sm",
    "aria-label": "Previous month"
  }, /*#__PURE__*/React.createElement(Icons.chevL, {
    size: 16
  })), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "icon-sm",
    "aria-label": "Next month"
  }, /*#__PURE__*/React.createElement(Icons.chevR, {
    size: 16
  })))), /*#__PURE__*/React.createElement("div", {
    className: "cal-grid cal-dow"
  }, ["Mo", "Tu", "We", "Th", "Fr", "Sa", "Su"].map(d => /*#__PURE__*/React.createElement("span", {
    key: d
  }, d))), /*#__PURE__*/React.createElement("div", {
    className: "cal-grid"
  }, cells.map((d, i) => {
    if (!d) return /*#__PURE__*/React.createElement("span", {
      key: i
    });
    const avail = isAvailable(d);
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      className: "cal-day",
      disabled: !avail,
      "data-selected": selected === d,
      "data-today": d === today,
      onClick: () => {
        setSelected(d);
        setSlot(null);
      }
    }, d);
  }))), /*#__PURE__*/React.createElement("div", {
    className: "sched-times"
  }, /*#__PURE__*/React.createElement("div", {
    className: "times-head"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13.5
    }
  }, /*#__PURE__*/React.createElement("strong", {
    style: {
      fontWeight: 600
    }
  }, "Wed 24"), " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--muted-foreground)"
    }
  }, "June")), /*#__PURE__*/React.createElement(Tabs, {
    value: fmt,
    onValueChange: setFmt,
    tabs: [{
      value: "12h",
      label: "12h"
    }, {
      value: "24h",
      label: "24h"
    }]
  })), /*#__PURE__*/React.createElement("div", {
    className: "times-list"
  }, slots.map(s => /*#__PURE__*/React.createElement("button", {
    key: s,
    className: "slot",
    "data-active": slot === s,
    onClick: () => setSlot(s)
  }, s)))), /*#__PURE__*/React.createElement("div", {
    className: "sched-foot"
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onBack
  }, /*#__PURE__*/React.createElement(Icons.arrowL, {
    size: 16
  }), " All events"), /*#__PURE__*/React.createElement(Button, {
    variant: "brand",
    disabled: !slot,
    onClick: () => onConfirm({
      day: selected,
      slot
    })
  }, "Continue")));
}
Object.assign(window, {
  Scheduler
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/Scheduler.jsx", error: String((e && e.message) || e) }); }

// ui_kits/scheduling/icons.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Lucide-style stroke icons (2px, round) — matches coss's icon language.
const Icon = ({
  d,
  size = 18,
  sw = 2,
  fill = "none",
  style
}) => /*#__PURE__*/React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: fill,
  stroke: "currentColor",
  strokeWidth: sw,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: style,
  "aria-hidden": "true"
}, d);
const Icons = {
  clock: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 7v5l3 2"
    }))
  })),
  video: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "2",
      y: "6",
      width: "13",
      height: "12",
      rx: "2"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m22 8-5 4 5 4V8Z"
    }))
  })),
  globe: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M3 12h18M12 3a15 15 0 0 1 0 18 15 15 0 0 1 0-18Z"
    }))
  })),
  calendar: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("rect", {
      x: "3",
      y: "4.5",
      width: "18",
      height: "17",
      rx: "2.5"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M3 9h18M8 2.5v4M16 2.5v4"
    }))
  })),
  chevL: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "m15 18-6-6 6-6"
    })
  })),
  chevR: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "m9 18 6-6-6-6"
    })
  })),
  arrowL: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M19 12H5"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m12 19-7-7 7-7"
    }))
  })),
  check: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "M20 6 9 17l-5-5"
    })
  })),
  checkCircle: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "9"
    }), /*#__PURE__*/React.createElement("path", {
      d: "m8.5 12 2.5 2.5 4.5-5"
    }))
  })),
  mapPin: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("path", {
      d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
    }), /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "10",
      r: "2.6"
    }))
  })),
  user: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "8",
      r: "3.6"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M5 20a7 7 0 0 1 14 0"
    }))
  })),
  phone: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement("path", {
      d: "M5 4h3l2 5-2.5 1.5a11 11 0 0 0 5 5L17 18l-1 3a16 16 0 0 1-13-13Z"
    })
  })),
  sun: p => /*#__PURE__*/React.createElement(Icon, _extends({}, p, {
    d: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("circle", {
      cx: "12",
      cy: "12",
      r: "4"
    }), /*#__PURE__*/React.createElement("path", {
      d: "M12 2v2M12 20v2M4 12H2M22 12h-2M5 5l1.5 1.5M17.5 17.5 19 19M19 5l-1.5 1.5M6.5 17.5 5 19"
    }))
  }))
};
Object.assign(window, {
  Icon,
  Icons
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/scheduling/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.AlertTitle = __ds_scope.AlertTitle;

__ds_ns.AlertDescription = __ds_scope.AlertDescription;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardTitle = __ds_scope.CardTitle;

__ds_ns.CardDescription = __ds_scope.CardDescription;

__ds_ns.CardContent = __ds_scope.CardContent;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
