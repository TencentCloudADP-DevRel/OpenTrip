# cossUI — Design System

A recolored take on **coss.com/ui** (the official Cal.com design system,
formerly Origin UI), retuned to the palette of a reference portrait: cool
silver-white light, navy ink dark, and a single cornflower-blue accent — the
hair ribbon. The brief in one word: **restraint**. coss's own aesthetic is
already quiet and exact, so the work here was to shift its warm Tailwind-neutral
spine to a cool blue-grey and let cornflower carry the brand wherever a hint of
color is earned — and nowhere else.

> Built for **Lynn** · brand "cossUI".

## Sources

This system is derived from one repository — read it for ground truth:

- **GitHub:** `cosscom/coss` — https://github.com/cosscom/coss
  - `packages/ui/src/styles/globals.css` — the original token system (semantic
    aliases over a Tailwind ramp). Our `tokens/colors.css` mirrors its structure.
  - `packages/ui/src/components/*.tsx` — Base UI + CVA component sources we
    recreated (button, badge, input, card, checkbox, switch, alert…).
  - `packages/ui/src/fonts/` — Cal Sans, Cal Sans UI, Paper Mono webfonts
    (imported into `assets/fonts/`).

  Explore the repo to build higher-fidelity work: the `apps/www` marketing
  pages (`scheduling`, `calendar`, `email`) and `apps/ui` docs show the system
  in real product context.

- **Reference image:** `uploads/optimized_4k_vector_style.jpeg` — the source of
  the palette (cool blue-grey field, navy sailor collar, cornflower ribbon,
  silver-white hair).

> The reader may not have access to the repo above; values are recorded here so
> the system stands alone, but the repo is the best place to go deeper.

---

## Content fundamentals

coss writes like a calm, competent tool — never loud. The voice is plain,
second-person, and confident without hype.

- **Person & tone.** Addresses **you** ("Pick a time that works for you"),
  speaks of itself as **we** ("We're building it in the open"). Friendly, direct,
  engineering-honest. No exclamation marks, no growth-hacking adjectives.
- **Casing.** Sentence case everywhere — headings, buttons, labels
  ("Book a meeting", "Confirm booking"). The wordmark is lowercase: `coss/ui`.
- **Length.** Terse. A title is 2–5 words; a description is one clause. Buttons
  are a verb or verb-noun ("Continue", "Confirm booking", "Book another time").
- **Numbers & time** live in Paper Mono — durations ("30m"), slots ("9:30 am"),
  versions, code. This is a deliberate texture, not decoration.
- **Emoji:** none. **Exclamation:** rare. The product earns trust by being quiet.
- **Examples:** "Schedule without the back-and-forth" · "Built in the open, for
  everyone" · "A calendar invite is on its way."

---

## Visual foundations

- **Color.** A cool blue-grey neutral spine (`--ink-*`, hue ~260, very low
  chroma) from silver-white (`--ink-50`) to navy ink (`--ink-800`, the primary).
  One accent: **cornflower** (`--corn-500`, the ribbon) reserved for focus rings,
  links, selection, and a single hero action per view. Status colors are used as
  **8–16% tints**, almost never as solid fills. Build on the semantic aliases
  (`--background`, `--foreground`, `--primary`, `--brand`, `--muted`, `--border`).
- **Type.** Cal Sans for display headings (tight −0.02em tracking), Cal Sans UI
  for interface text (14px base — small, dense, even), Paper Mono for numerics
  and code. Modest scale steps; no dramatic jumps.
- **Spacing.** 4px base step. Comfortable but not airy — coss packs information
  at a 13–14px body size with tight, consistent gaps.
- **Backgrounds.** Flat. The page is a near-white cool field; cards are pure
  white to lift off it. **No gradients, no imagery, no texture, no blur** unless
  a product genuinely needs it. Restraint is the texture.
- **Borders & elevation.** Every surface is a **hairline border** (`--border`,
  ~9% ink) plus a faint **top-highlight** (`--highlight-top`, a 1px inner white
  line that reads as lit-from-above) over a **restrained, cool-tinted shadow**.
  Shadows are small (`--shadow-xs`/`sm`); `lg` only for the booking card and
  popovers. No drop-shadow drama.
- **Corner radii.** Base 10px (`--radius`). Buttons/inputs `lg` (10px), badges
  `sm` (6px), alerts/popovers `xl` (14px), cards `2xl` (16px), avatars/switch
  full. Consistent, never mixed at random.
- **Cards.** Rounded-2xl, hairline border, top-highlight, soft shadow, white
  surface. Calm headers (Cal Sans title + muted description), generous 24px pad.
- **Hover.** Filled buttons darken ~10% toward the background; ghost/outline
  fade in a 4–6% accent wash; interactive cards shift their border toward
  cornflower. Transitions ~120–150ms ease.
- **Press.** The lit top-highlight collapses to an inset shadow (the surface
  "presses in"); no scale-down except the switch thumb's brief squash.
- **Focus.** A 3px cornflower ring at 24% over a 1px background offset — the one
  place the accent always appears. This is the brand's signature interaction.
- **Animation.** Sparing. Fades and short eases; the switch thumb slides. No
  bounces, no infinite loops, no parallax.
- **Imagery vibe.** When imagery appears (rare), it's cool and desaturated to
  match the field — like the reference portrait. Default to no imagery.

---

## Interaction & polish

Restraint decides *what* moves; these design-engineering rules (from
*jakubkrehel/make-interfaces-feel-better*) decide *how well*. Full detail in
`guidelines/interaction.md`; the **Polish** specimen cards demo each one.

- **Scale on press** — `scale(0.96)` (`--press-scale`) on `:active` for buttons,
  checkbox, calendar days, slots; `static` prop opts a button out. Never < 0.95.
- **Interruptible transitions** — every hover/toggle/press is a CSS transition on
  *specific* properties (never `transition: all`); keyframes only for one-shot
  enters.
- **Split & stagger enter** — screens fade/blur/translate-up per chunk ~90ms
  apart (`--enter-stagger`, `--ease-out`), gated on `prefers-reduced-motion`; the
  end-state is the base style so refresh & reduced-motion show content instantly.
- **Concentric radius** — outer = inner + padding; the radius scale is sized for it.
- **Shadow as border** — `--shadow-border` / `--shadow-border-hover` for elevated
  surfaces on varied backgrounds; real borders stay for dividers & input outlines.
- **Image outlines** — pure black/white 1px inset outline on every `<img>`, never
  a tinted ink.
- **Tabular numerics** — `tabular-nums` on all dynamic numbers (times, slots,
  counters) so they never shift layout; Paper Mono is tabular by default.
- **Text wrapping** — `balance` on headings/titles, `pretty` on body & captions.
- **Font smoothing** — antialiased + grayscale at the root.
- **40×40 hit areas** — small controls extend via a pseudo-element, never overlapping.

---

## Iconography

coss uses **HugeIcons** (`@hugeicons/react`) and **lucide-react** — thin,
2px, round-cap, round-join **stroke** icons, never filled or duotone. They sit
at ~`size-4` (16–18px) inline with text, at 80% opacity beside labels.

- In this system, the UI kit ships a small inline **Lucide-style** set
  (`ui_kits/scheduling/icons.jsx`) — clock, video, calendar, chevrons, check,
  user, etc. — matching that stroke language. This is a substitution for the
  real icon packages; **for production, use `lucide-react` / HugeIcons**.
- **Emoji:** never. **Unicode glyphs as icons:** avoid — use a real stroke icon.
- Pull icons from https://lucide.dev (CDN-available) when you need more than the
  bundled set, keeping stroke-width 2 and round caps.

---

## Index — what's in this folder

**Foundations**
- `styles.css` — the single entry consumers link (imports only).
- `tokens/colors.css` — `--ink-*`, `--corn-*` ramps + semantic aliases (+ `.dark`).
- `tokens/typography.css` — font stacks, type scale, weights, tracking.
- `tokens/spacing.css` — radius, spacing, elevation, **shadow-as-border**,
  **press-scale / easing / stagger**, focus-ring tokens.
- `tokens/fonts.css` — `@font-face` for Cal Sans / Cal Sans UI / Paper Mono.
- `assets/fonts/` — the webfont binaries.

**Specimen cards** (Design System tab) — `guidelines/`
- Colors: `color-ink`, `color-cornflower`, `color-semantic`, `color-status`.
- Type: `type-display`, `type-body`, `type-mono`.
- Spacing: `radius`, `spacing`, `elevation`.
- Polish: `polish-press`, `polish-concentric`, `polish-tabular`,
  `polish-shadow-border`, `polish-stagger` (+ `interaction.md` deep-dive).

**Components** — `components/core/` (namespace `window.CossUIDesignSystem_2babcc`)
- `Button`, `Badge`, `Input`, `Card` (+ parts), `Checkbox`, `Switch`, `Alert`
  (+ parts), `Avatar`, `Tabs`. Each ships `.jsx` + `.d.ts` + `.prompt.md`, with
  `*.card.html` specimens (buttons, badges, forms, card, feedback).

**UI kit** — `ui_kits/scheduling/`
- A Cal-style public booking flow (event → time → details → confirmed),
  composing the primitives. See its `README.md`.

**Skill**
- `SKILL.md` — makes this folder usable as a downloadable Agent Skill.

---

## Using it

Link the single stylesheet and read components off the namespace:

```html
<link rel="stylesheet" href="styles.css" />
<script src="_ds_bundle.js"></script>
<script type="text/babel">
  const { Button, Card } = window.CossUIDesignSystem_2babcc;
</script>
```

Reskin by editing the `--ink-*` / `--corn-*` ramps in `tokens/colors.css`;
everything semantic follows.
